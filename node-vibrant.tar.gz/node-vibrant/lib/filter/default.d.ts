export default function defaultFilter(r: number, g: number, b: number, a: number): boolean;
