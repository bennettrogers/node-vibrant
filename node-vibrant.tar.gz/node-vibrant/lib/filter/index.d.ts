export { default as Default } from './default';
import { Filter } from '../typing';
export declare function combineFilters(filters: Filter[]): Filter;
