import { Generator } from '../typing';
declare const MultiGenerator: Generator;
export default MultiGenerator;
