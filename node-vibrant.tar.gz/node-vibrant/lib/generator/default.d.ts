import { Generator } from '../typing';
declare const DefaultGenerator: Generator;
export default DefaultGenerator;
