import { Quantizer } from '../typing';
declare const quantizeInWorker: Quantizer;
export default quantizeInWorker;
