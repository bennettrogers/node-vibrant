import { Quantizer } from '../typing';
export { default as MMCQ } from './mmcq';
export declare var WebWorker: Quantizer;
