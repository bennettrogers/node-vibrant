import { Pixels, ComputedOptions } from '../typing';
import { Swatch } from '../color';
declare const MMCQ: (pixels: Pixels, opts: ComputedOptions) => Swatch[];
export default MMCQ;
