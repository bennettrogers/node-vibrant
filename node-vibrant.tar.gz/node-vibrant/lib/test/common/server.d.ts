/// <reference types="node" />
import http = require('http');
export declare const createSampleServer: () => http.Server;
